import os
import concurrent.futures
from deep_translator import GoogleTranslator
from tqdm import tqdm
import json
from utills import get_filename


def translate_chunk(chunk, dest_lang):
    try:
        translated_text = GoogleTranslator(source='auto', target=dest_lang).translate(chunk)
    except:
        print(" Ошибка перевода этого фрагмента, повторная попытка...")
        translated_text = GoogleTranslator(source='auto', target=dest_lang).translate(chunk)

    return translated_text


def translate_file(dest_lang):

    with open(f'data/temp/all_chapters.json', 'r', encoding='utf-8') as f:
        data = json.load(f)

    novel_name = data[0]["novel_name"]
    file_path = get_filename(novel_name)

    with open(f'data/novel/' + file_path + '.txt', 'r', encoding='utf-8') as f:
        text = f.read()

    MAX_CHUNK_LENGTH = 4990
    chunks = [text[i:i+MAX_CHUNK_LENGTH] for i in range(0, len(text), MAX_CHUNK_LENGTH)]
    total_chunks = len(chunks)
    with concurrent.futures.ThreadPoolExecutor() as executor:
        chunk_futures = [executor.submit(translate_chunk, chunk, dest_lang) for chunk in chunks]

    translated_texts = [f.result() for f in chunk_futures]
    translated_text = ''.join(translated_texts)

    new_file_path = f'data/novel/{file_path}'

    with open(new_file_path + '.txt', 'w', encoding='utf-8') as f:
            f.write(translated_text)
    print(" Перевод завершен.")


if __name__ == '__main__':
    dest_lang = input(" Введите язык перевода: ")
    translate_file(dest_lang)
