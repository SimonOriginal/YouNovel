import aiohttp
import asyncio
import concurrent.futures
import json
from bs4 import BeautifulSoup
from tqdm import tqdm
import time


async def fetch_chapter(session, url, headers, count, chapter_name):
    async with session.get(url, headers=headers) as resp:
        src = await resp.text()
        with open(f"data/html/{count}.html", "w", encoding='utf-8') as file:
            file.write(src)
        soup = BeautifulSoup(src, "lxml")
        chapter_content = soup.find(class_="chapter-content")
        if chapter_content is None:
            # print("Error: Could not find element with class 'chapter-content'.")
            return

        h1_tag = soup.find('div', {'class': 'titles'})
        novel_name = h1_tag.find('a').get('title')

        chapter_content_p = chapter_content.text
        json_data = [{
            "novel_name": novel_name,
            "chapter_name": chapter_name,
            "content": chapter_content_p
        }]

        with open(f"data/json/{count}.json", "w", encoding='utf-8') as file:
            json.dump(json_data, file, indent=10, ensure_ascii=False)


async def main():
    headers = {
        "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0"
    }

    with open(f'data/temp/all_chapter_links.json', encoding='utf-8') as file:
        all_chapter = json.load(file)

    iteration_count = len(all_chapter)
    count = 1
    print(f" Количество глав для прочтения: {iteration_count}")
    with tqdm(total=iteration_count, leave=True) as pbar:
        async with aiohttp.ClientSession() as session:
            tasks = []
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for chapter_href, chapter_name in all_chapter.items():
                    chapter_name = "".join(
                        c for c in chapter_name if c.isnumeric())
                    task = asyncio.ensure_future(fetch_chapter(
                        session, chapter_href, headers, count, chapter_name))
                    tasks.append(task)
                    pbar.update(1)
                    count += 1
                await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
